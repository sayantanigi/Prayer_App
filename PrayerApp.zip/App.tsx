import { SnackBarProvider } from "./Component/SnackBar";
import { StyleSheet } from "react-native";
import { RootNavigation } from "./RootNavigation";
import React from "react";

export default function App() {
  return (
    <SnackBarProvider>
      <RootNavigation />
    </SnackBarProvider>
  );
}

const styles = StyleSheet.create({
  Container: {},
});
