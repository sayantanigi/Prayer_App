import { useNavigation } from "@react-navigation/native";
import React from "react";
import { KeyboardAvoidingView, SafeAreaView, StyleSheet, View, Image, Text, TextInput, ScrollView, Pressable } from "react-native";
import * as Haptics from "expo-haptics";
import { BackgroundColor, HeadingColor, PrimaryColor } from "../../../../Constant/Color";
import { Back_2, Icon_18, Icon_19, Icon_20, Icon_21, Icon_22, Logo } from "../../../../Constant/Images";
import Link from "../../../../Component/Link";

export default function U_SignUpScreen() {
    const navigation = useNavigation<any>();

    // Haptics
    async function handleRouting(route: string) {
        await Haptics.selectionAsync();
        navigation.navigate(route);
    }

    return (
        <SafeAreaView style={styles.Container}>
            <KeyboardAvoidingView>
                <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.Body}>
                    {/* Logo */}
                    <View style={styles.LogoContainer}>
                        <Image
                            style={styles.Logo}
                            source={Logo} resizeMode="contain" />
                    </View>

                    <Text style={styles.Heading}>Become an <Text style={{ color: PrimaryColor }}>User</Text></Text>

                    {/* Input Field */}
                    <View style={styles.InputContainer}>
                        {/* first name input field */}
                        <View style={styles.Input}>
                            <TextInput style={styles.InputField} placeholder="First Name">
                            </TextInput>
                            <Image style={styles.InputImg} source={Back_2} />
                            <View style={styles.Icon}>
                                <Image
                                    source={Icon_22}
                                    style={styles.IconImage}
                                ></Image>
                            </View>
                        </View>

                        {/* last name input field */}
                        <View style={[styles.Input, styles.Gap]}>
                            <TextInput style={styles.InputField} placeholder="Last Name">
                            </TextInput>
                            <Image style={styles.InputImg} source={Back_2} />
                            <View style={styles.Icon}>
                                <Image
                                    source={Icon_22}
                                    style={styles.IconImage}
                                ></Image>
                            </View>
                        </View>

                        {/* email input field */}
                        <View style={[styles.Input, styles.Gap]}>
                            <TextInput style={styles.InputField} keyboardType="email-address" placeholder="Email Address">
                            </TextInput>
                            <Image style={styles.InputImg} source={Back_2} />
                            <View style={styles.Icon}>
                                <Image
                                    source={Icon_21}
                                    style={styles.IconImage}
                                ></Image>
                            </View>
                        </View>

                        {/* address input field */}
                        <View style={[styles.Input, styles.Gap]}>
                            <TextInput style={styles.InputField} placeholder="Address">
                            </TextInput>
                            <Image style={styles.InputImg} source={Back_2} />
                            <View style={styles.Icon}>
                                <Image
                                    source={Icon_20}
                                    style={styles.IconImage}
                                ></Image>
                            </View>
                        </View>

                        {/* password input field */}
                        <View style={[styles.Input, styles.Gap]}>
                            <TextInput style={styles.InputField} secureTextEntry={true} placeholder="Password">
                            </TextInput>
                            <Image style={styles.InputImg} source={Back_2} />
                            <View style={styles.Icon}>
                                <Image
                                    source={Icon_18}
                                    style={styles.IconImage}
                                ></Image>
                            </View>
                        </View>

                        {/* confirm password input field */}
                        <View style={[styles.Input, styles.Gap]}>
                            <TextInput style={styles.InputField} secureTextEntry={true} placeholder="Confirm Password">
                            </TextInput>
                            <Image style={styles.InputImg} source={Back_2} />
                            <View style={styles.Icon}>
                                <Image
                                    source={Icon_18}
                                    style={styles.IconImage}
                                ></Image>
                            </View>
                        </View>

                        <View
                            style={{
                                flexGrow: 1,
                                flexDirection: "row",
                                alignItems: "center",
                                justifyContent: "center",
                                width: "100%",
                                marginTop: 25,
                            }}
                        >
                            <Text
                                style={{
                                    fontSize: 16,
                                    letterSpacing: 1,
                                    fontFamily: "Inter-Regular",
                                }}
                            >
                                Already have an account?{" "}
                                <Link
                                    style={{ color: PrimaryColor, fontFamily: "Inter-Regular" }}
                                    to="U_SignInScreen"
                                >
                                    Sign in
                                </Link>
                            </Text>
                        </View>

                        {/* Button */}
                        <Pressable onPress={() => navigation.navigate("U_SignInScreen")}>
                            <View style={styles.Button}>
                                <Image style={styles.ButtonBackImg} source={Icon_19} />
                            </View>
                        </Pressable>
                    </View>
                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView >
    );
}

const styles = StyleSheet.create({
    Container: {
        flex: 1,
        backgroundColor: BackgroundColor,
    },
    Body: {
        height: "100%",
        flexDirection: "column",
        justifyContent: "space-evenly",
    },
    LogoContainer: {
    },
    Logo: {
        width: 100,
        height: 80,
        alignSelf: "center",
    },
    Heading: {
        fontFamily: "Inter-Bold",
        fontSize: 24,
        alignSelf: "center",
        color: HeadingColor,
    },
    InputContainer: {},
    Input: {
        width: 280,
        height: 50,
        alignSelf: "center",
        position: "relative",
    },
    InputField: {
        zIndex: 1,
        width: 280,
        height: 50,
        paddingLeft: 25,
        paddingRight: 25,
    },
    InputImg: {
        width: 280,
        height: 50,
        position: "absolute",
        zIndex: 0,
    },
    Icon: {
        position: "absolute",
        right: -5,
        top: -5,
        zIndex: 2,
    },
    IconImage: {
        width: 60,
        height: 60,
    },
    Gap: {
        marginTop: 20,
    },
    Button: {
        alignSelf: "center",
        height: 55,
        width: 55,
        marginTop: 20,
    },
    ButtonBackImg: {
        height: 55,
        width: 55,
    },
});