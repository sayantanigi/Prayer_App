import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import { StyleSheet, ScrollView, Text, View, Pressable, Image, Dimensions } from "react-native";
import { BackgroundColor, Black, PrimaryColor, TextColor, White } from "../../../Constant/Color";
import O_ScreenLayout from "./O_ScreenLayout";
import Link from "../../../Component/Link";
import { useMusicStore } from "../../../store/music";
import { Back_1, BlankImage, BlankVideo, HomeIcon_1, HomeIcon_2, HomeIcon_3, HomeIcon_4, HomeIcon_5 } from "../../../Constant/Images";

const apiData = [
    {
        coverImage: BlankImage,
        artist: "Song by Ed Sheeran",
        audio: require("../../../assets/Mp3/Music1.mp3"),
        title: "Perfect (Official Music Video)",
        details: "EP. 12: Daily Rosary Meditations | Ed Sheeran"
    },
    {
        coverImage: BlankImage,
        artist: "Song by Wiz Khalifa",
        audio: require("../../../assets/Mp3/Music2.mp3"),
        title: "See You Again ft. Charlie Puth",
        details: "EP. 13: Daily Rosary Meditations | Wiz Khalifa"
    },
    {
        coverImage: BlankImage,
        artist: "Song by Yanni",
        audio: require("../../../assets/Mp3/Music3.mp3"),
        title: "Nightingale - The Tribute Concerts",
        details: "EP. 14: Daily Rosary Meditations | Yanni"
    }
]

export default function O_HomeScreen() {
    const navigation = useNavigation<any>();
    const [shouldShow, setShouldShow] = useState(true);
    const [podcast, setPodcast] = useMusicStore();
    const video = React.useRef(null);

    return (
        <O_ScreenLayout
            BannerHidden
            ToolBarHidden
            VideoHidden
            ProductBuyHidden
            ProductCartHidden
            ProductCheckoutHidden
        >
            <ScrollView showsVerticalScrollIndicator={false} style={styles.Container}>
                {/* Alarm */}
                {shouldShow ? (
                    <>
                        <View style={{ paddingLeft: 20, paddingRight: 20, }}>
                            <View style={styles.AlarmBlock}>
                                <View style={styles.AlarmTimeBlock}>
                                    <Text style={styles.AlarmTime}>1:20 pm</Text>
                                </View>
                                <View style={styles.AlarmDataBlock}>
                                    <Text style={styles.AlarmText}>Its 1:20 Lets Pray</Text>
                                    <View style={styles.AlarmBtnBlock}>
                                        <Pressable style={styles.AlarmBtn} onPress={() => setShouldShow(!shouldShow)}>
                                            <Text style={styles.AlarmBtnText}>Stop Reminder</Text>
                                        </Pressable>
                                        <Link style={styles.AlarmBtn} to="O_AlarmScreen">
                                            <Text style={styles.AlarmBtnText}>Manage Reminder</Text>
                                        </Link>
                                    </View>
                                </View>
                                <Image style={styles.AlarmImgBack} source={HomeIcon_1} />
                            </View>
                        </View>
                    </>
                ) : (
                    <View style={{ paddingLeft: 20, paddingRight: 20, }}>
                        <View style={styles.AlarmBlock}>
                            <View style={styles.AlarmTimeBlock}>
                                <Text style={styles.AlarmTime}>1:20 pm</Text>
                            </View>
                            <View style={styles.AlarmDataBlock}>
                                <Text style={styles.AlarmText}>Its 1:20 Lets Pray</Text>
                                <View style={styles.AlarmBtnBlock}>
                                    <Pressable style={[styles.AlarmBtn, styles.StopAlarmReminder]} onPress={() => setShouldShow(!shouldShow)}>
                                        <Text style={styles.AlarmBtnText}>Start Reminder</Text>
                                    </Pressable>
                                    <View style={[styles.AlarmBtn, styles.StopAlarmReminder]}>
                                        <Text style={styles.AlarmBtnText}>Manage Reminder</Text>
                                    </View>
                                </View>
                            </View>
                            <Image style={styles.AlarmImgBack} source={HomeIcon_1} />
                        </View>
                    </View>
                )}

                {/* Upcoming Events */}
                <View style={styles.BlockData}>
                    <Text style={styles.BlockHeading}>Upcoming Events</Text>
                    <Link style={styles.ViewAll} to="O_EventScreen">
                        <Text style={styles.ViewAllText}>View All</Text>
                    </Link>
                </View>
                <Text style={styles.BlockSubHead}>Make plans to attend one of our prayer gatherings.</Text>

                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    bounces={false}
                    contentContainerStyle={styles.BlockContainer}>
                    {/* Single Event Tile Start */}
                    {new Array(3).fill(0).map((item, Eventindex) => (
                        < View key={Eventindex} style={styles.EventBlock} >
                            <View style={styles.EventData}>
                                <Image style={styles.EventImg} source={BlankImage} resizeMode="cover" />
                                <View style={styles.EventTextContainer}>
                                    <Text style={styles.EventHeading} numberOfLines={1}>Prayer Heading</Text>
                                    <Text style={styles.EventUserText} numberOfLines={1}>By User Name</Text>
                                    <Text style={styles.EventTime}>Event Date: 30-Agu-23</Text>
                                    <Text style={styles.EventTime}>Time: 08-30</Text>
                                </View>
                            </View>
                            <View style={styles.EventTimeBlock}>
                                <Image style={styles.EventTimeIcon} source={HomeIcon_2} />
                                <Image style={styles.EventTimeBack} source={Back_1} />
                                <Text style={styles.EventTimeText}>2 Days</Text>
                                <Text style={styles.EventTimeText}>4:30 Hours</Text>
                            </View>
                        </View>
                    ))}
                    {/* Single Event Tile End */}
                </ScrollView>

                {/* Prayer Wall */}
                <View style={styles.BlockData}>
                    <Text style={styles.BlockHeading}>Prayer Wall</Text>
                    <Link style={styles.ViewAll} to={"O_PrayerBoardScreen"}>
                        <Text style={styles.ViewAllText}>View All</Text>
                    </Link>
                </View>
                <Text style={styles.BlockSubHead}>Discover the recent prayer events in your area and attend them right now.</Text>

                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    bounces={false}
                    contentContainerStyle={styles.BlockContainer}>
                    {/* Single Prayer Tile Start */}
                    {new Array(3).fill(0).map((item, Prayerindex) => (
                        <View key={Prayerindex} style={styles.PrayerBlock}>
                            <View style={styles.PrayerData}>
                                <View style={styles.PrayerTextData}>
                                    <Text style={styles.PrayerHeading} numberOfLines={1}>Heading</Text>
                                    <Text style={styles.PrayerText} numberOfLines={1}>Location Address</Text>
                                    <Text style={styles.PrayerText} numberOfLines={1}>08:30</Text>
                                    <View style={styles.PrayerJoin}>
                                        <Image style={styles.PrayerJoinIcon} source={HomeIcon_3} resizeMode="center" />
                                        <Text style={styles.PrayerJoinText}>250 have joined already</Text>
                                    </View>
                                </View>
                                <View style={styles.PrayerImage}>
                                    <Image style={styles.PrayerImg} source={BlankImage} />
                                </View>
                            </View>
                            <View style={styles.PrayerBtnContainer}>
                                <Link style={styles.PrayerJoinBtn} to={"O_PrayerJoinScreen"}>
                                    <Text style={styles.PrayerJoinBtnText}>Join Now</Text>
                                    <Image style={styles.PrayerJoinBtnBack} source={HomeIcon_4} resizeMode="center" />
                                </Link>
                                <Link style={styles.PrayerViewBtn} to={"O_PrayerDetailsScreen"}>
                                    <Text style={styles.PrayerViewText}>View Details</Text>
                                </Link>
                            </View>
                        </View>
                    ))}
                    {/* Single Prayer Tile End */}
                </ScrollView>

                {/* Podcasts */}
                <View style={styles.BlockData}>
                    <Text style={styles.BlockHeading}>Latest Podcasts</Text>
                    <Link style={styles.ViewAll} to={"O_PodcastScreen"}>
                        <Text style={styles.ViewAllText}>View All</Text>
                    </Link>
                </View>
                <Text style={styles.BlockSubHead}>Listen to our most recent podcast about our numerous types of prayer events.</Text>

                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    bounces={false}
                    contentContainerStyle={styles.BlockContainer}>
                    {/* Single Podcast Tile Start */}
                    {apiData.map((data, Podcastindex) => (
                        <Pressable
                            onPress={() => {
                                setPodcast(data)
                            }}
                            key={Podcastindex} style={styles.PodBlock}>
                            <Text style={styles.PodLang}>English</Text>
                            <Text style={styles.PodHeading} numberOfLines={2}>{data.title}</Text>
                            <Text style={styles.PodSubHeading} numberOfLines={1}>{data.artist}</Text>
                            <Image style={styles.PodPlayIcon} source={HomeIcon_5} resizeMode="center" />
                            <View style={styles.PodImgContainer}>
                                <View style={styles.PodOverlay}></View>
                                <Image style={styles.PodImg} source={BlankImage} resizeMode="cover" />
                            </View>
                        </Pressable>
                    ))}
                    {/* Single Podcast Tile End */}
                </ScrollView>

                {/* Video */}
                <View style={styles.BlockData}>
                    <Text style={styles.BlockHeading}>Latest Videos</Text>
                    <Link style={styles.ViewAll} to={"O_VideoScreen"}>
                        <Text style={styles.ViewAllText}>View All</Text>
                    </Link>
                </View>
                <Text style={styles.BlockSubHead}>Discover our most recent prayers, posts, and more.</Text>

                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    bounces={false}
                    contentContainerStyle={styles.BlockContainer}>
                    {/* Single Video Tile Start */}
                    {new Array(3).fill(0).map((item, Videoindex) => (
                        <Pressable key={Videoindex} style={styles.VideoBlock} onPress={() => navigation.navigate("O_VideoPlayerScreen")}>
                            <View style={styles.VideoData}>
                                <Image style={styles.VideoImg} source={BlankVideo} resizeMode="cover" />
                            </View>
                            <View style={styles.VideoOwner}>
                                <View style={styles.VideoOwnerText}>
                                    <Image style={styles.VideoOwnerImg} source={BlankImage} resizeMode="center" />
                                    <Text style={styles.VideoOwnerHeading} numberOfLines={2}>Name and details of the video are displayed here</Text>
                                </View>
                                <Text style={styles.VideoOwnerView}>12K View</Text>
                            </View>
                        </Pressable>
                    ))}
                    {/* Single Video Tile End */}
                </ScrollView>
            </ScrollView>
        </O_ScreenLayout >
    );
}

const styles = StyleSheet.create({
    Container: {
        flex: 1,
        backgroundColor: BackgroundColor,
        width: "100%",
        height: "100%",
        paddingTop: 20,
    },
    // Common Styles
    BlockData: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingTop: 20,
        paddingBottom: 5,
        paddingLeft: 20,
        paddingRight: 20,
    },
    BlockHeading: {
        fontSize: 20,
        fontFamily: "Inter-SemiBold",
    },
    ViewAll: {
        alignItems: "center",
        justifyContent: "center",
        width: 70,
        height: 25,
        elevation: 10,
        backgroundColor: White,
        borderRadius: 100
    },
    ViewAllText: {
        fontSize: 12,
        fontFamily: "Inter-SemiBold",
        color: PrimaryColor
    },
    BlockSubHead: {
        fontSize: 15,
        fontFamily: "Inter-Regular",
        color: TextColor,
        letterSpacing: 1.5,
        paddingLeft: 20,
        paddingRight: 20,
        marginTop: 5,
        marginBottom: 20
    },
    BlockContainer: {
        paddingLeft: 20,
        paddingRight: 20,
        paddingTop: 10,
        paddingBottom: 10,
        gap: 15,
    },

    // Alarm
    AlarmBlock: {
        flexDirection: "row",
        width: Dimensions.get("window").width - 50,
        height: 100,
        borderRadius: 10,
        elevation: 3,
        backgroundColor: White,
        position: "relative",
        padding: 10,
    },
    AlarmTimeBlock: {
        alignItems: "center",
        justifyContent: "center",
        width: 80,
        elevation: 10,
        backgroundColor: White,
        borderRadius: 10,
    },
    AlarmTime: {
        fontFamily: "Inter-SemiBold",
        fontSize: 15,
        color: PrimaryColor,
    },
    AlarmDataBlock: {
        flexDirection: "column",
        justifyContent: "space-between",
        paddingLeft: 10,
    },
    AlarmText: {
        fontFamily: "Inter-SemiBold",
        fontSize: 15,
        color: White,
    },
    AlarmBtnBlock: {
        flexDirection: "row",
        justifyContent: "space-between",
        gap: 10,
    },
    AlarmBtn: {
        backgroundColor: PrimaryColor,
        borderRadius: 100,
        width: 110,
        height: 35,
        alignItems: "center",
        justifyContent: "center",
    },
    AlarmBtnText: {
        fontFamily: "Inter-SemiBold",
        fontSize: 10,
        color: White,
    },
    AlarmImgBack: {
        position: "absolute",
        width: Dimensions.get("window").width - 50,
        height: 100,
        borderRadius: 10,
        top: 0,
        left: 0,
        zIndex: -1,
    },
    StopAlarmReminder: {
        backgroundColor: Black,
        opacity: .7,
    },

    // Upcoming Events
    EventBlock: {
        flexDirection: "row",
        justifyContent: "space-between",
        width: Dimensions.get("window").width - 50,
        borderRadius: 10,
        elevation: 3,
        backgroundColor: White,
    },
    EventData: {
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        paddingLeft: 10,
    },
    EventImg: {
        width: 80,
        height: 80,
        borderRadius: 10
    },
    EventTextContainer: {
        flexDirection: "column",
        paddingLeft: 10,
    },
    EventHeading: {
        fontFamily: "Inter-SemiBold",
        fontSize: 15,
        color: PrimaryColor,
        width: 120,
    },
    EventUserText: {
        fontFamily: "Inter-Regular",
        fontSize: 10,
        color: TextColor,
        marginBottom: 5,
        width: 120,
    },
    EventTime: {
        fontFamily: "Inter-Medium",
        fontSize: 10,
        color: Black,
        lineHeight: 1.5 * 10
    },
    EventTimeBlock: {
        position: "relative",
        width: 90,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
    },
    EventTimeBack: {
        width: 90,
        height: "100%",
        position: "absolute",
        zIndex: -1,
        borderTopRightRadius: 10,
        borderBottomRightRadius: 10
    },
    EventTimeIcon: {
        width: 40,
        height: 40,
        marginBottom: 5,
    },
    EventTimeText: {
        fontFamily: "Inter-SemiBold",
        fontSize: 12,
        lineHeight: 1.5 * 12,
        color: White,
    },

    // Prayer Wall
    PrayerBlock: {
        width: Dimensions.get("window").width - 50,
        borderRadius: 10,
        elevation: 3,
        backgroundColor: White,
        padding: 10,
        paddingBottom: 15,
    },
    PrayerData: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    PrayerTextData: {},
    PrayerHeading: {
        fontFamily: "Inter-SemiBold",
        fontSize: 15,
        color: PrimaryColor,
        marginBottom: 10,
        width: 200,
    },
    PrayerText: {
        fontFamily: "Inter-Regular",
        fontSize: 10,
        color: TextColor,
        width: 200,
    },
    PrayerJoin: {
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 20,
        marginTop: 10,
    },
    PrayerJoinIcon: {
        width: 15,
        height: 15,
        marginRight: 5,
    },
    PrayerJoinText: {
        fontFamily: "Inter-Medium",
        fontSize: 10,
        color: Black,
        lineHeight: 1.5 * 10
    },
    PrayerImage: {
        alignItems: "flex-start",
        justifyContent: "flex-start",
        height: "100%",
    },
    PrayerImg: {
        width: 85,
        height: 85,
        borderRadius: 100,
    },
    PrayerBtnContainer: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginTop: 10,
    },
    PrayerJoinBtn: {
        width: 130,
        height: 45,
        elevation: 5,
        borderRadius: 100,
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
    },
    PrayerJoinBtnText: {
        fontFamily: "Inter-SemiBold",
        fontSize: 15,
        color: White
    },
    PrayerJoinBtnBack: {
        width: 130,
        height: 45,
        position: "absolute",
        zIndex: -1
    },
    PrayerViewBtn: {
        width: 130,
        height: 45,
        elevation: 5,
        backgroundColor: White,
        borderRadius: 100,
        alignItems: "center",
        justifyContent: "center",
    },
    PrayerViewText: {
        fontFamily: "Inter-SemiBold",
        fontSize: 14,
        color: PrimaryColor
    },

    // Podcasts
    PodBlock: {
        width: Dimensions.get("window").width - 50,
        borderRadius: 10,
        elevation: 3,
        height: 180,
        position: "relative",
        padding: 10,
    },
    PodLang: {
        color: White,
        fontFamily: "Inter-Medium",
        fontSize: 13,
    },
    PodHeading: {
        color: White,
        fontFamily: "Inter-SemiBold",
        fontSize: 20,
        position: "absolute",
        left: 10,
        bottom: 30,
        width: 250,
    },
    PodSubHeading: {
        color: White,
        fontFamily: "Inter-Medium",
        fontSize: 13,
        position: "absolute",
        left: 10,
        bottom: 10,
        width: 250,
    },
    PodPlayIcon: {
        position: "absolute",
        width: 50,
        height: 50,
        right: 10,
        bottom: 10,
    },
    PodImgContainer: {
        width: Dimensions.get("window").width - 50,
        height: 180,
        position: "absolute",
        top: 0,
        left: 0,
        zIndex: -1,
    },
    PodOverlay: {
        width: Dimensions.get("window").width - 50,
        height: 180,
        position: "absolute",
        top: 0,
        left: 0,
        zIndex: 1,
        backgroundColor: Black,
        opacity: .4,
        borderRadius: 10,
    },
    PodImg: {
        width: Dimensions.get("window").width - 50,
        height: 180,
        borderRadius: 10,
    },

    // Video
    VideoBlock: {
        width: Dimensions.get("window").width - 50,
    },
    VideoData: {
        width: Dimensions.get("window").width - 50,
        borderRadius: 10,
        elevation: 3,
        height: 180,
        position: "relative",
    },
    VideoImg: {
        width: Dimensions.get("window").width - 50,
        height: 180,
        borderRadius: 10,
    },
    VideoOwner: {
        flexDirection: "row",
        marginTop: 10,
        alignItems: "center",
        justifyContent: "space-between",
    },
    VideoOwnerImg: {
        width: 40,
        height: 40,
        borderRadius: 100,
    },
    VideoOwnerText: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    VideoOwnerHeading: {
        fontSize: 12,
        fontFamily: "Inter-Medium",
        width: 200,
        paddingLeft: 10,
    },
    VideoOwnerView: {
        fontSize: 12,
        fontFamily: "Inter-Medium",
    },
});